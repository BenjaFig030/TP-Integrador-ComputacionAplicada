#!/bin/bash

#Este es el primer script que tengo que crear para el apartado 5 Backup
#Script de Backup backup_full.sh

#Opcion de ayuda si el usuario escribe -help
if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 <directorio_origen> <directorio_destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

#Valida argumentos para destino y origen
if [[ $# -ne 2 ]]; then
	echo "Error: Se requieren 2 argumentos"
	echo "Usa $0 -help para más información"
	exit 1
fi

ORIGEN=$1
DESTINO=$2

#Valida que origen y destino estén disponibles antes de ejecutar backup
if ! mountpoint -q "$DESTINO"; then
	echo "Error: El destino '$DESTINO' no está montado"
	exit 3
fi

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen '$ORIGEN' no existe"
	exit 2
fi

#Creación de archivo
FECHA=$(date +%Y%m%d)
NOMBRE_ARCHIVO=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

#Creación del backup
tar -czf "$DESTINO/$NOMBRE_ARCHIVO" "$ORIGEN"

#Bloque extra para verificar el contenido con exito o error
if [[ $? -eq 0 ]]; then
	echo "Backup creado con exito en: $DESTINO/$NOMBRE_ARCHIVO"
else
	echo "Error durante la creacion del backup"
fi


